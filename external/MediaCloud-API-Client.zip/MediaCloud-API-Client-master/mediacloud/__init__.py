
from api import MediaCloud
from storage import *

VERSION = "2.1"
